exports.id = 811;
exports.ids = [811];
exports.modules = {

/***/ 9918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8409);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_icons_GitHub__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5956);
/* harmony import */ var _material_ui_icons_GitHub__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_GitHub__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7985);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_Create__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _material_ui_icons_Create__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Create__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_icons_Functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4154);
/* harmony import */ var _material_ui_icons_Functions__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Functions__WEBPACK_IMPORTED_MODULE_5__);









const Footer = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
    className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default().footer),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
      href: "https://github.com/palexander227",
      target: "_blank",
      rel: "noreferrer",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_material_ui_icons_GitHub__WEBPACK_IMPORTED_MODULE_2___default()), {}), "\xA0Github"]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
      href: "https://www.linkedin.com/in/peter-alexander-4a444127",
      target: "_blank",
      rel: "noreferrer",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__.LinkedIn, {}), "\xA0LinkedIn"]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
      href: "https://ctan.org/?lang=en",
      target: "_blank",
      rel: "noreferrer",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_material_ui_icons_Create__WEBPACK_IMPORTED_MODULE_4___default()), {}), "\xA0CTAN"]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
      href: "https://tug.org",
      target: "_blank",
      rel: "noreferrer",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_material_ui_icons_Functions__WEBPACK_IMPORTED_MODULE_5___default()), {}), "\xA0TUG"]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

/***/ }),

/***/ 7978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(2571);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Button/Button.js
var Button = __webpack_require__(282);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/ClickAwayListener/ClickAwayListener.js
var ClickAwayListener = __webpack_require__(2795);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Grow/Grow.js + 6 modules
var Grow = __webpack_require__(5516);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Paper/Paper.js
var Paper = __webpack_require__(9895);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Popper/Popper.js + 2 modules
var Popper = __webpack_require__(5603);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/MenuItem/MenuItem.js
var MenuItem = __webpack_require__(5639);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/MenuList/MenuList.js + 1 modules
var MenuList = __webpack_require__(7617);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/styles/makeStyles.js
var makeStyles = __webpack_require__(1120);
// EXTERNAL MODULE: external "@material-ui/icons/Menu"
var Menu_ = __webpack_require__(1358);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
;// CONCATENATED MODULE: ./src/components/HamburgerMenu/index.js



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













/*
    The following warning shows up because the material-ui team hasn't kept up with React devs. The material ui team is working on a fix. 
    Warning: findDOMNode is deprecated in StrictMode.
    https://stackoverflow.com/questions/61220424/material-ui-drawer-finddomnode-is-deprecated-in-strictmode

    And className did not match bug:
    https://github.com/vercel/next.js/issues/7322
*/

const useStyles = (0,makeStyles/* default */.Z)(theme => ({
  root: {
    display: 'flex'
  },
  paper: {
    marginRight: theme.spacing(2)
  },
  burger: {
    color: 'white!important'
  }
}));

const HamburgerMenu = () => {
  const classes = useStyles();
  const [open, setOpen] = external_react_default().useState(false);
  const anchorRef = external_react_default().useRef(null);

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  const handleClose = event => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  function handleListKeyDown(event) {
    if (event.key === 'Tab') {
      event.preventDefault();
      setOpen(false);
    }
  } // return focus to the button when we transitioned from !open -> open


  const prevOpen = external_react_default().useRef(open);
  external_react_default().useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: classes.root,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
        ref: anchorRef,
        "aria-controls": open ? 'menu-list-grow' : undefined,
        "aria-haspopup": "true",
        onClick: handleToggle,
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: classes.burger,
          children: /*#__PURE__*/jsx_runtime_.jsx((Menu_default()), {})
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(Popper/* default */.Z, {
        open: open,
        anchorEl: anchorRef.current,
        role: undefined,
        transition: true,
        disablePortal: true,
        children: ({
          TransitionProps,
          placement
        }) => /*#__PURE__*/jsx_runtime_.jsx(Grow/* default */.Z, _objectSpread(_objectSpread({}, TransitionProps), {}, {
          style: {
            transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom'
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(Paper/* default */.Z, {
            children: /*#__PURE__*/jsx_runtime_.jsx(ClickAwayListener/* default */.Z, {
              onClickAway: handleClose,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(MenuList/* default */.Z, {
                autoFocusItem: open,
                id: "menu-list-grow",
                onKeyDown: handleListKeyDown,
                children: [/*#__PURE__*/jsx_runtime_.jsx(MenuItem/* default */.Z, {
                  onClick: handleClose,
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: "Home"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(MenuItem/* default */.Z, {
                  onClick: handleClose,
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/about",
                    children: "About"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(MenuItem/* default */.Z, {
                  onClick: handleClose,
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/projects",
                    children: "Projects"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(MenuItem/* default */.Z, {
                  onClick: handleClose,
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/contact",
                    children: "Contact"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(MenuItem/* default */.Z, {
                  onClick: handleClose,
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "https://portfolio-react-2021.s3.us-west-1.amazonaws.com/pdfs/Peter_s_Resume.pdf",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      target: "_blank",
                      children: "Resume"
                    })
                  })
                })]
              })
            })
          })
        }))
      })]
    })
  });
};

/* harmony default export */ const components_HamburgerMenu = (HamburgerMenu);
;// CONCATENATED MODULE: ./src/components/Navbar/index.js








const Navbar = () => {
  const router = (0,router_.useRouter)();

  const linkClass = pathname => {
    return router.pathname == pathname ? `${(Navbar_module_default()).item} ${(Navbar_module_default())["active-link"]}` : (Navbar_module_default()).item;
  };

  return /*#__PURE__*/jsx_runtime_.jsx("nav", {
    className: (Navbar_module_default()).nav,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      className: (Navbar_module_default()).menu,
      children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).logo,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: "Peter Alexander"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Navbar_module_default()).hamburgerMenu,
        children: /*#__PURE__*/jsx_runtime_.jsx(components_HamburgerMenu, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: linkClass('/'),
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: "Home"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: linkClass('/about'),
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/about",
          children: "About"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: linkClass('/projects'),
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/projects",
          children: "Projects"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: linkClass('/contact'),
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/contact",
          children: "Contact"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: linkClass('https://portfolio-react-2021.s3.us-west-1.amazonaws.com/pdfs/Peter_s_Resume.pdf'),
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "https://portfolio-react-2021.s3.us-west-1.amazonaws.com/pdfs/Peter_s_Resume.pdf",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            target: "_blank",
            children: "Resume"
          })
        })
      })]
    })
  });
};

/* harmony default export */ const components_Navbar = (Navbar);

/***/ }),

/***/ 2571:
/***/ ((module) => {

// Exports
module.exports = {
	"hamburgerMenu": "Navbar_hamburgerMenu__3uNrX",
	"nav": "Navbar_nav__2b98f",
	"active-link": "Navbar_active-link__1g6hD",
	"menu": "Navbar_menu__3XD5o",
	"submenu": "Navbar_submenu__3ZvGt",
	"logo": "Navbar_logo__3vj75",
	"item": "Navbar_item__U5k3X",
	"button": "Navbar_button__1Adtb",
	"subitem": "Navbar_subitem__L3vOu",
	"toggle": "Navbar_toggle__3sPaU",
	"active": "Navbar_active__3fEct",
	"secondary": "Navbar_secondary__2RZ4Z",
	"submenu-active": "Navbar_submenu-active__2Obtt",
	"has-submenu": "Navbar_has-submenu__vwXS1"
};


/***/ }),

/***/ 8409:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__1EcsU",
	"main": "Home_main__1x8gC",
	"footer": "Home_footer__1WdhD",
	"title": "Home_title__3DjR7",
	"description": "Home_description__17Z4F",
	"code": "Home_code__axx2Y",
	"grid": "Home_grid__2Ei2F",
	"card": "Home_card__2SdtB",
	"logo": "Home_logo__1YbrH"
};


/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;